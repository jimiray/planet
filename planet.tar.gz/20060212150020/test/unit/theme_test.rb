require File.dirname(__FILE__) + '/../test_helper'

class ThemeTest < Test::Unit::TestCase
  fixtures :themes

  # Replace this with your real tests.
  def test_truth
    assert_kind_of Theme, themes(:first)
  end
end
