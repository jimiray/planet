require File.dirname(__FILE__) + '/../../test_helper'
require 'admin/sidebar_controller'

# Re-raise errors caught by the controller.
class Admin::SidebarController; def rescue_action(e) raise e end; end

class Admin::SidebarControllerTest < Test::Unit::TestCase
  def setup
    @controller = Admin::SidebarController.new
    @request    = ActionController::TestRequest.new
    @response   = ActionController::TestResponse.new
  end

  # Replace this with your real tests.
  def test_truth
    assert true
  end
end
