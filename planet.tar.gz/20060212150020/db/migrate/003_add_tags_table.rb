class AddTagsTable < ActiveRecord::Migration

  def self.up
    create_table :tags do |table|
      table.column :name, :string
    end
  end

  def self.down
    drop_table :tags
  end

end
