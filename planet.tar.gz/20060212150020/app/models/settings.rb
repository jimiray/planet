class Settings < ActiveRecord::Base
end
